package com.zybooks.projecttwo;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class LowInventoryNotificationHelper {

    // Low inventory Notification channel strings
    private static final String CHANNEL_ID = "low_Inventory";
    private static final String CHANNEL_NAME = "Low Inventory";
    private static final String CHANNEL_DESC = "Low Inventory Notification Message";

    // function to display Low Inventory notification
    public static void displayLowInventoryNotification(Context context, String itemName){

        // call preferences from the settings activity
        SharedPreferences sharedPreferences = context.getSharedPreferences("AppSettings",Context.MODE_PRIVATE);
        boolean enableLowInventorySwitch = sharedPreferences.getBoolean("Low_Inventory_Notifications_Enabled", true);

        // Stop if switch is not enabled
        if(!enableLowInventorySwitch){
            return;
        }

        // Runs code to creates notification channel if android version is greater than android oreo
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(CHANNEL_DESC);

            // Code to create the notification channel
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        // Create an object of Notification builder
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notifications)
                .setContentTitle("Low Inventory")
                .setContentText(itemName + "'s stock is low! Time to reorder it!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        //Create Notification Manager for the Low Inventory Notification
        NotificationManagerCompat.from(context).notify((int) System.currentTimeMillis(), mBuilder.build());

    }

}
