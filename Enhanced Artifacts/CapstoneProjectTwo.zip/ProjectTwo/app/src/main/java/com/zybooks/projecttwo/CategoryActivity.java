package com.zybooks.projecttwo;

import static com.zybooks.projecttwo.R.*;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class CategoryActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton addCategoryButton;
    ImageButton settingsButton;
    InventoryDatabaseHelper myDB;

    ArrayList<String> categoryNames, categoryID;

    CategoryAdapter categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_category);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerView);
        addCategoryButton = findViewById(R.id.addCategoryButton);
        settingsButton = findViewById(R.id.settingsButton);

        myDB = new InventoryDatabaseHelper(CategoryActivity.this);
        categoryNames = new ArrayList<>();
        categoryID = new ArrayList<>();

        storeCategories();


        categoryAdapter = new CategoryAdapter(CategoryActivity.this,CategoryActivity.this, categoryNames, categoryID);
        recyclerView.setAdapter(categoryAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(CategoryActivity.this));

        /*
        // On Click Listener for the floating action button
        addCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //myDB.addCategory("New Category"); // later replace with user input
                recreate();
            }
        });
        */
        // On Click Listener for the Settings button on the header
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CategoryActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });
        addCategoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(CategoryActivity.this);
                builder.setTitle("Add Category");

                final EditText input = new EditText(CategoryActivity.this);
                input.setHint("Enter category name");
                builder.setView(input);

                builder.setPositiveButton("Add", (dialog, which) -> {
                    String categoryName = input.getText().toString().trim();

                    if(categoryName.isEmpty()){
                        Toast.makeText(CategoryActivity.this, "Category name cannot be empty", Toast.LENGTH_SHORT).show();
                    } else {
                        myDB.addCategory(categoryName);

                        // refresh list
                        categoryNames.clear();
                        categoryID.clear();
                        storeCategories();
                        categoryAdapter.notifyDataSetChanged();
                    }
                });

                builder.setNegativeButton("Cancel", null);

                builder.show();
            }
        });

    }
    public void storeCategories(){
        Cursor cursor = myDB.getAllCategories();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Data.", Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                categoryNames.add(cursor.getString(cursor.getColumnIndexOrThrow("Category_Name")));
                categoryID.add(cursor.getString(cursor.getColumnIndexOrThrow("Category_ID")));

            }
        }
    }
}
