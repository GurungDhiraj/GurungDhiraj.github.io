package com.zybooks.projecttwo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    private Context context;
    private ArrayList item_name, item_ID, item_amount;

    Activity activity;

    CustomAdapter(Activity activity, Context context, ArrayList item_name, ArrayList item_ID, ArrayList item_amount){
        this.activity = activity;
        this.context = context;
        this.item_name = item_name;
        this.item_ID = item_ID;
        this.item_amount = item_amount;
    }

    // class for handling filtered list
    public void setFilteredList(ArrayList<String> filteredList){
        this.item_name = filteredList;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, int position) {

        holder.item_name.setText(String.valueOf(item_name.get(position)));
        holder.item_ID.setText(String.valueOf(item_ID.get(position)));
        holder.item_amount.setText(String.valueOf(item_amount.get(position)));

        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int adapterPosition = holder.getBindingAdapterPosition();

                if(adapterPosition != RecyclerView.NO_POSITION) {
                    Intent intent = new Intent(context, UpdateInventoryActivity.class);
                    intent.putExtra("name", String.valueOf(item_name.get(adapterPosition)));
                    intent.putExtra("id", String.valueOf(item_ID.get(adapterPosition)));
                    intent.putExtra("amount", String.valueOf(item_amount.get(adapterPosition)));
                    activity.startActivityForResult(intent, 1);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return item_name.size();
    }

    class MyViewHolder extends ViewHolder{

        TextView item_name, item_ID, item_amount;
        LinearLayout mainLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            item_name = itemView.findViewById(R.id.item_name);
            item_ID = itemView.findViewById(R.id.item_ID);
            item_amount = itemView.findViewById(R.id.item_amount);
            mainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}
