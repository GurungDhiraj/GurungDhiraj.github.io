package com.zybooks.projecttwo;

import java.util.HashMap;
import java.util.Map;

public class Credentials {
    // Use hashmaps to store username and password
   HashMap<String, String> credentialsMapper = new HashMap<String, String>();

   // Add login information to the hashmap
   public void addCredentials(String username, String password){
       credentialsMapper.put(username, password);
   }

   // Function to return username, used to see if username already exists
   public boolean checkUsername(String username){
       return credentialsMapper.containsKey(username);
   }

   // Function to check if username exists and password matches
   public boolean verifyCredentials(String username, String password){
       // Check to see if username exists
       if(credentialsMapper.containsKey(username)){
           // checks to see if password matches
           if(password.equals(credentialsMapper.get(username))){
               return true;
           }
       }

       // return false if username doesn't exist or if password doesn't match
       return false;
   }

   // Function to load credentials when app starts
    // We use ? because the value could be boolean (RememberMeCheckbox) or string
   public void loadCredentials(Map<String, ?> preferencesMap){
       for(Map.Entry<String, ?> entries: preferencesMap.entrySet()){
           // Filter out the checkbox from entries, we only want username and password
           if(!entries.getKey().equals("RememberMeCheckbox")){
                credentialsMapper.put(entries.getKey(), entries.getValue().toString());
           }

       }
   }
}
