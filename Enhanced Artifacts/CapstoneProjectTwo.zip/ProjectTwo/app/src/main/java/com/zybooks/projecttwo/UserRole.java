package com.zybooks.projecttwo;

public enum UserRole {
    // Roles for the app
    ADMIN,EMPLOYEE;

}
