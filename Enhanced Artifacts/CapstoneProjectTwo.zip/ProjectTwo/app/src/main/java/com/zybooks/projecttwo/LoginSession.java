package com.zybooks.projecttwo;

public class LoginSession {
    // Volatile is used to read directly from memory,
    // so multiple threads can handle the instance properly
    private static volatile LoginSession instance;
    // Attributes for user's login information
    private String username;
    private UserRole userRole;

    // Constructor to create objects for this class
    private LoginSession(){
    }

    // Class to guarantee only one instance/user is returned each time
    public static LoginSession getInstance(){
        // uses local variable to store instance, so you only read memory once
        LoginSession result = instance;

        // double checked locking idiom to ensure only one instance of LoginSession
        if (result == null){
            synchronized (LoginSession.class){
                result = instance;

                if (result == null){
                    instance = result = new LoginSession();
                }
            }
        }
        return  result;
    }

    // sets user login information
    public void setLoginInfo(String username, UserRole userRole){
        this.username = username;
        this.userRole = userRole;
    }

    // getter to return userRole
    public UserRole getUserRole(){
        return userRole;
    }

    // getter to return username
    public String getUsername(){
        return username;
    }

}
