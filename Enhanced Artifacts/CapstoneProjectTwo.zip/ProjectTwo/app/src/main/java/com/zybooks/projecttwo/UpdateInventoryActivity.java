package com.zybooks.projecttwo;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UpdateInventoryActivity extends AppCompatActivity {

    EditText name_input, ID_input, amount_input;
    Button update_button, delete_button;

    String name, id, amount;

    // variable to track low inventory
    private static final int LOW_INVENTORY_THRESHOLD = 10;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        name_input = findViewById(R.id.name_input2);
        ID_input = findViewById(R.id.ID_input2);
        amount_input = findViewById(R.id.amount_input2);
        update_button = findViewById(R.id.update_button);
        delete_button = findViewById(R.id.delete_button);

        // Call the getAndSetIntentData() function first
        getAndSetIntentData();

        // Find toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set actionbar title after getAndSetIntentData() method
        ActionBar ab = getSupportActionBar();
        if(ab != null){
            ab.setDisplayHomeAsUpEnabled(true);
            ab.setDisplayShowHomeEnabled(true);
            ab.setTitle(name);
        }

        // Update Button Onclick Listener
        update_button.setOnClickListener((view) -> {
            InventoryDatabaseHelper myDB = new InventoryDatabaseHelper(UpdateInventoryActivity.this);
            // After setting the data then we can update it
            myDB.updateData(name_input.getText().toString().trim(), ID_input.getText().toString().trim(), amount_input.getText().toString().trim());

            // Convert amount_input into an int
            int item_Inventory = Integer.parseInt(amount_input.getText().toString());

            // Check to see if inventory is low and Trigger notification if inventory is low
            if(item_Inventory <= LOW_INVENTORY_THRESHOLD){
                LowInventoryNotificationHelper.displayLowInventoryNotification(this, name_input.getText().toString().trim());
            }

            finish();
        });

        // Delete Button Onclick Listener
        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the confirmDialog method
                confirmDialog();
            }
        });

        // get loginSession instance
        LoginSession session = LoginSession.getInstance();

        // Logic to hide delete button for EMPLOYEE Role
        if (session.getUserRole() == UserRole.EMPLOYEE) {
            // hides delete button
            delete_button.setVisibility(View.GONE);
        }
    }

    void getAndSetIntentData(){
        if(getIntent().hasExtra("name") && getIntent().hasExtra("id") && getIntent().hasExtra("amount")){

            // Get Data from Intent
            name = getIntent().getStringExtra("name");
            id = getIntent().getStringExtra("id");
            amount = getIntent().getStringExtra("amount");

            // Set Intent Data
            name_input.setText(name);
            ID_input.setText(id);
            amount_input.setText(amount);

        } else{
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

    // confirmDialog
    void confirmDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + name + " ?");
        builder.setMessage("Are you sure you want to delete " + name + " ?");

        // Yes Button Onlcick listener
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                InventoryDatabaseHelper myDB = new InventoryDatabaseHelper(UpdateInventoryActivity.this);
                myDB.deleteOneRow(id);
                finish();
            }
        });

        // No Button Onlcick listener
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        builder.create().show();

    }

    // Method for allowing the back button to show up on the Update Inventory Activity page
    @Override
    public boolean onSupportNavigateUp() {
        // go back to Parent activity -> InventoryActivity
        finish();
        return true;
    }
}