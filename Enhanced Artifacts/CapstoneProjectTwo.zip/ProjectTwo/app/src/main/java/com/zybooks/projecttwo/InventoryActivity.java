package com.zybooks.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton addButton;
    ImageButton settingsButton;

    InventoryDatabaseHelper myDB;

    ArrayList<String> item_name, item_ID, item_amount;
    CustomAdapter customAdapter;

    SearchView searchView;

    int category_ID;
    String category_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        category_ID = getIntent().getIntExtra("category_ID", -1);
        category_name = getIntent().getStringExtra("category_name");

        recyclerView = findViewById(R.id.recyclerView);
        addButton = findViewById(R.id.addButton);
        settingsButton = findViewById(R.id.settingsButton);
        searchView = findViewById(R.id.searchView);
        searchView.clearFocus();

        // On Click Listener for searchView bar
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return false;
            }
        });

        // On Click Listener for the floating action button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, AddInventoryActivity.class);
                intent.putExtra("category_ID", category_ID);
                startActivity(intent);
            }
        });

        // On Click Listener for the Settings button on the header
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        myDB = new InventoryDatabaseHelper(InventoryActivity.this);
        item_name = new ArrayList<>();
        item_ID = new ArrayList<>();
        item_amount = new ArrayList<>();

        //storeDataInArrays();
        storeDataInArraysByCategory();

        customAdapter = new CustomAdapter(InventoryActivity.this,InventoryActivity.this, item_name, item_ID, item_amount);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(InventoryActivity.this));

    }

    // method for SearchView
    private void filterList(String text) {
        ArrayList<String> filteredList = new ArrayList<>();

        // Loop through list to find specific items
        for(int i = 0; i < item_name.size(); i++){
            if(item_name.get(i).toLowerCase().contains(text.toLowerCase())){
                filteredList.add(item_name.get(i));
            }
        }

        // Notify if item is not found
        if(filteredList.isEmpty()){
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
        }else{
            customAdapter.setFilteredList(filteredList);

        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        item_name.clear();
        item_ID.clear();
        item_amount.clear();

        //storeDataInArrays();
        storeDataInArraysByCategory();
        customAdapter.notifyDataSetChanged();
    }

    public void storeDataInArraysByCategory(){
        Cursor cursor = myDB.getItemsByCategory(category_ID);

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Data.", Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                item_name.add(cursor.getString(cursor.getColumnIndexOrThrow("Item_Name")));
                item_ID.add(cursor.getString(cursor.getColumnIndexOrThrow("id")));
                item_amount.add(cursor.getString(cursor.getColumnIndexOrThrow("Item_Amount")));
            }
        }
    }
}