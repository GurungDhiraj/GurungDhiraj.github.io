package com.zybooks.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Map;

public class RegistrationActivity extends AppCompatActivity {

    // Create variables for edit text and button values for activity
    private EditText regName;
    private EditText regPass;
    private Button register;

    // Create credentials object
    public Credentials credentials;

    // Shared Preferences is used to store the credentials
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor sharedPreferencesEditor;

    // Create object of UserRole
    UserRole employee = UserRole.EMPLOYEE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registration);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        regName = findViewById(R.id.regUsername);
        regPass = findViewById(R.id.regPassword);
        register = findViewById(R.id.registerButton);

        // Instantiate credentials class
        credentials = new Credentials();

        // Creates a database to store the credentials
        sharedPreferences = getApplicationContext().getSharedPreferences("CredentialsDB", MODE_PRIVATE);
        // Editor to manage the values in the database
        sharedPreferencesEditor = sharedPreferences.edit();

        // Ensure file contains a username and password
        if(sharedPreferences != null){

            // Stores login information in this map
            Map<String, ?> preferencesMap = sharedPreferences.getAll();

            // checks to see if there are any values in the preferencesMap
            if(!preferencesMap.isEmpty()){
                credentials.loadCredentials(preferencesMap);
            }

        }

        // Set onclick listener for button
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String regUsername = regName.getText().toString();
                String regPassword = regPass.getText().toString();

                // set the new credentials
                if(validate(regUsername, regPassword)){

                    // Check to see if username is already taken
                    if(credentials.checkUsername(regUsername)){
                        Toast.makeText(RegistrationActivity.this, "Username already taken", Toast.LENGTH_SHORT).show();

                    } else {
                        // create credentials
                        credentials.addCredentials(regUsername, regPassword);

                        // Store the credentials
                        sharedPreferencesEditor.putString(regUsername, regPassword);

                        // Saves newly registered credentials
                        sharedPreferencesEditor.putString("savedUsername", regUsername);
                        sharedPreferencesEditor.putString("savedPassword", regPassword);

                        sharedPreferencesEditor.apply();  // Line that actually applies the above changes into the file

                        startActivity(new Intent(RegistrationActivity.this, MainActivity.class));
                        Toast.makeText(RegistrationActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });
    }

    // Validate if the username and password is entered correctly
    private boolean validate(String username, String password){
        if(username.isEmpty() || password.isEmpty() || password.length() < 8){
            Toast.makeText(this, "Please fill in the field. Password should be at least 8 letters!", Toast.LENGTH_SHORT).show();
            // Return false if there is an error in the fields, but true if there are no errors
            return false;
        }

        return true;
    }
}