package com.zybooks.projecttwo;


import static android.app.DownloadManager.COLUMN_TITLE;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {
    private Context context;

    private static final String DATABASE_NAME = "Inventory.db";
    private static  final int DATABASE_VERSION = 4;

    // Columns for Category Tables
    private static final String TABLE_CATEGORY = "Category_Table";
    private static final String CATEGORY_ID = "Category_ID";
    private static final String CATEGORY_NAME = "Category_Name";


    // Columns for Inventory Tables
    private static final String TABLE_NAME = "Inventory";
    private static final String COLUMN_NAME = "Item_Name";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_AMOUNT = "Item_Amount";
    InventoryDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    // Function to create database on Oncreate
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create Category tables
        String createCategoryTable = "CREATE TABLE " + TABLE_CATEGORY +
                " (" + CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CATEGORY_NAME + " TEXT);";

        // SQL statement to create Inventory tables
        String createInventoryTable =
                "CREATE TABLE " + TABLE_NAME +
                        " (" + COLUMN_NAME + " TEXT, " +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_AMOUNT + " FLOAT," +
                        CATEGORY_ID + " INTEGER);";

        // Create the tables
        db.execSQL(createCategoryTable);
        db.execSQL(createInventoryTable);
    }

    // Function to delete all table records
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Clears table data
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORY);

        // recreate the tables
        onCreate(db);
    }

    // Function to add different categories
    public void addCategory(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("Category_Name", name);
        long result = db.insert(TABLE_CATEGORY, null, cv);

        // Output for when Data fails to insert
        if(result == -1){
            Toast.makeText(context, "Insert Data Failed", Toast.LENGTH_SHORT).show();
        }
        // Output for when Data successfully inserts
        else{
            Toast.makeText(context, "Data Successfully Added", Toast.LENGTH_SHORT).show();
        }
    }

    // Function to retrieve all category Tables
    Cursor getAllCategories(){
        String query = "SELECT * FROM " + TABLE_CATEGORY;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;

        if(db != null){
            cursor = db.rawQuery(query, null);
        }

        return cursor;
    }

    // Function to retrieve items in category Tables
    Cursor getItemsByCategory(int categoryId){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        if(db != null){ /* *** */
            String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + CATEGORY_ID + " = ?";
            String[] selectionArgs = {String.valueOf(categoryId)};

            cursor = db.rawQuery(query, selectionArgs);
        }

        return cursor;
    }

    // Function to add item within inventory database
    public void addItem(String name,int ID, float amount, int categoryID){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_NAME, name);
        cv.put(COLUMN_ID, ID);
        cv.put(COLUMN_AMOUNT, amount);
        cv.put(CATEGORY_ID, categoryID);

        long result = db.insert(TABLE_NAME, null, cv);

        // Output for when Data fails to insert
        if(result == -1){
            Toast.makeText(context, "Insert Data Failed", Toast.LENGTH_SHORT).show();
        }
        // Output for when Data successfully inserts
        else{
            Toast.makeText(context, "Data Successfully Added", Toast.LENGTH_SHORT).show();
        }
    }


    Cursor readAllData() {
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }

        return cursor;
    }

    void updateData(String name, String id, String amount){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_NAME, name);
        //cv.put(COLUMN_ID, id);
        cv.put(COLUMN_AMOUNT, Float.parseFloat(amount));

        long result = db.update(TABLE_NAME, cv, "id=?", new String[]{id});
        if(result == 0){
            Toast.makeText(context, "Failed to Update.", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Successfully Updated!", Toast.LENGTH_SHORT).show();

        }

    }

    void deleteOneRow(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME, "id=?", new String[]{id});

        if(result == 0){
            Toast.makeText(context, "Failed to Delete.", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Successfully Deleted", Toast.LENGTH_SHORT).show();
        }
    }
}
