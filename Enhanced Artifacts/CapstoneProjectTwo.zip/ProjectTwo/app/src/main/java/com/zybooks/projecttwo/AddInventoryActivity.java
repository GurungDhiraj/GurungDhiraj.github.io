package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddInventoryActivity extends AppCompatActivity {

    EditText name_input, ID_input, amount_input;
    int categoryID;
    Button add_button;
    ImageButton settingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        categoryID = getIntent().getIntExtra("category_ID", -1);

        // Find the id of the given elements w/ add item page
        name_input = findViewById(R.id.name_input);
        ID_input = findViewById(R.id.ID_input);
        amount_input = findViewById(R.id.amount_input);
        add_button = findViewById(R.id.add_button);
        settingsButton = findViewById(R.id.settingsButton);

        // Find toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set actionbar title after getAndSetIntentData() method
        ActionBar ab = getSupportActionBar();

        if(ab != null){
            ab.setDisplayHomeAsUpEnabled(true);
            ab.setDisplayShowHomeEnabled(true);
            ab.setTitle("Add Item");
        }


        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InventoryDatabaseHelper myDB = new InventoryDatabaseHelper(AddInventoryActivity.this);
                myDB.addItem(name_input.getText().toString().trim(),
                        Integer.parseInt(ID_input.getText().toString().trim()),
                        Float.parseFloat(amount_input.getText().toString().trim()),
                        categoryID);
                finish();
            }
        });

        // On Click Listener for the Settings button on the header
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddInventoryActivity.this, SettingsActivity.class));
            }
        });


    }


}