package com.zybooks.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Map;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    Button loginButton;

    private EditText userName;
    private EditText password;
    private TextView signUp;
    private CheckBox rememberMe;

    boolean isTrue = false;

    public Credentials credentials;

    // Create Shared Preferences variables
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor sharedPreferencesEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Find the correct element by their id
        //recyclerView = findViewById(R.id.recyclerView);
        loginButton = findViewById(R.id.loginButton);
        userName = findViewById(R.id.userName);
        password = findViewById(R.id.password);
        signUp = findViewById(R.id.newUserSignUPMessage);
        rememberMe = findViewById(R.id.rememberMeCheckBox);

        // Instantiate credentials class
        credentials = new Credentials();

        // Creates a database to store the credentials
        sharedPreferences = getApplicationContext().getSharedPreferences("CredentialsDB", MODE_PRIVATE);
        sharedPreferencesEditor = sharedPreferences.edit();

        // call function to create Admin account
        createAdminAccount();

        // Only call the sharedPreferences file if that file contains a username and password
        if(sharedPreferences != null){

            // Stores login information in this map
            Map<String, ?> preferencesMap = sharedPreferences.getAll();

            // checks to see if there are any values in the preferencesMap
            if(!preferencesMap.isEmpty()){
                credentials.loadCredentials(preferencesMap);
            }

            // used to store username and pass even after exiting the app
            // so user does not have to log back in
            String savedUsername = sharedPreferences.getString("savedUsername", "");
            String savedPassword = sharedPreferences.getString("savedPassword", "");

            //RegistrationActivity.credentials = new Credentials(savedUsername, savedPassword);

            // Check if the Remember me checkbox was checked or not
            if(sharedPreferences.getBoolean("RememberMeCheckbox", false)){
                userName.setText(savedUsername);
                password.setText(savedPassword);
                rememberMe.setChecked(true);
            }
        }

        // rememberMe checkbox onClickListener
        rememberMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // checks to see if the rememberMe checkbox is checked or not
                sharedPreferencesEditor.putBoolean("RememberMeCheckbox", rememberMe.isChecked());
                sharedPreferencesEditor.apply(); // commits the changes to the checkbox
            }
        });

        // signUp textview onClickListener
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Send users to Registration Activity after clicking signUp Button
                startActivity(new Intent(MainActivity.this, RegistrationActivity.class));
            }
        });


        // Login Button onClickListener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputName = userName.getText().toString();
                String inputPassword = password.getText().toString();

                if(inputName.isEmpty() || inputPassword.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    isTrue = validateLogin(inputName, inputPassword);

                    // What to do if the password and username don't match
                    if(!isTrue){
                        Toast.makeText(MainActivity.this, "Incorrect Username or Password", Toast.LENGTH_SHORT).show();
                    }
                    // What to do if the password and username are correct
                    else {
                        //Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                        // Check if user is admin
                        if(inputName.equals("Admin") && inputPassword.equals("pass1234")){
                            // Set role to ADMIN
                            LoginSession.getInstance().setLoginInfo(inputName, UserRole.ADMIN);

                            // Pop-Up message to show that you are logged in as Admin
                            Toast.makeText(MainActivity.this, "Logged in as ADMIN", Toast.LENGTH_SHORT).show();

                            // Passes values to sharedPreferencesEditor once login is successful
                            sharedPreferencesEditor.putString("savedUsername", inputName);
                            sharedPreferencesEditor.putString("savedPassword", inputPassword);
                            sharedPreferencesEditor.apply();

                            // Send user to the next activity
                            startActivity(new Intent(MainActivity.this, CategoryActivity.class));
                        } else {
                            // Set role to EMPLOYEE
                            LoginSession.getInstance().setLoginInfo(inputName, UserRole.EMPLOYEE);

                            // Pop-Up message to show that you are logged in as EMPLOYEE
                            Toast.makeText(MainActivity.this, "Logged in as EMPLOYEE", Toast.LENGTH_SHORT).show();

                            // Passes values to sharedPreferencesEditor once login is successful
                            sharedPreferencesEditor.putString("savedUsername", inputName);
                            sharedPreferencesEditor.putString("savedPassword", inputPassword);
                            sharedPreferencesEditor.apply();

                            // Send user to the next activity
                            startActivity(new Intent(MainActivity.this, CategoryActivity.class));
                        }

                        // Send user to the next activity
                        //startActivity(new Intent(MainActivity.this, InventoryActivity.class));
                    }

                }

                //finish();

            }
        });
    }

    // Function to verify if username and password is correct
    private boolean validateLogin(String name, String password){
        // calls the verify Credentials function and returns a boolean
        return credentials.verifyCredentials(name, password);
    };

    // Function to hardcode Admin account information
    private void createAdminAccount(){
        // Checks to see if Admin account is created
        if(!sharedPreferences.contains("Admin")){
            // Adds Admin username and password to sharedPreferencesEditor
            sharedPreferencesEditor.putString("Admin", "pass1234");
            sharedPreferencesEditor.apply();
        }
    }
}