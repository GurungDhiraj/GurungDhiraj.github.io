package com.zybooks.projecttwo;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
//import android.widget.ImageButton;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SettingsActivity extends AppCompatActivity {
    // SMS notification code
    private static final int smsRequestCode = 101;
    private static final int lowInventoryCode = 102;
    private Switch smsNotificationSwitch, lowInventoryNotificationSwitch;
    private SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // set shared preferences at beginning
        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);

        // Find lowInventory notification switch
        lowInventoryNotificationSwitch = findViewById(R.id.lowInventorySwitch);

        // boolean value for LowInventory switch
        boolean enableLowInventorySwitch = sharedPreferences.getBoolean("Low_Inventory_Notifications_Enabled", true);
        lowInventoryNotificationSwitch.setChecked(enableLowInventorySwitch);

        // Logic for low inventory switch
        lowInventoryNotificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {

                // Runs code to give notification if Android version is greater than Android Tiramisu
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        ContextCompat.checkSelfPermission(SettingsActivity.this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(SettingsActivity.this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, lowInventoryCode);

                } else {
                    // Save permission granted preference
                    saveLowInventoryPreference(true);
                }
            }
            else {
                // Save permission NOT granted preference
                saveLowInventoryPreference(false);
            }

        });

        // find SMS switch by ID
        smsNotificationSwitch = findViewById(R.id.smsNotificationSwitch);

        // Find toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set actionbar title after getAndSetIntentData() method
        ActionBar ab = getSupportActionBar();

        if(ab != null){
            ab.setDisplayHomeAsUpEnabled(true);
            ab.setDisplayShowHomeEnabled(true);
            ab.setTitle("Settings");
        }

        // boolean value for SMS switch
        boolean enableSMS = sharedPreferences.getBoolean("SMS_Enabled", false);
        smsNotificationSwitch.setChecked(enableSMS);

        // Logic to enable or disable SMS notifications
        smsNotificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (isChecked) {
                // Check and request permission if turning ON
                if (ContextCompat.checkSelfPermission(SettingsActivity.this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(SettingsActivity.this, new String[]{Manifest.permission.RECEIVE_SMS}, smsRequestCode);
                }
                else {
                    // Save permission granted preference
                    saveSmsPreference(true);
                }
            }
            else {
                // Save permission NOT granted preference
                saveSmsPreference(false);
            }

        });
    }

    // Logic to display SMS preference enabled or disabled
    private void saveSmsPreference(boolean isEnabled){
        sharedPreferences.edit().putBoolean("SMS_Enabled", isEnabled).apply();
        Toast.makeText(this, "SMS Notifications " + (isEnabled ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
    }

    // Logic to display low Inventory preference enabled or disabled
    private void saveLowInventoryPreference(boolean isEnabled){
        sharedPreferences.edit().putBoolean("Low_Inventory_Notifications_Enabled", isEnabled).apply();
        Toast.makeText(this, "Low Inventory Notifications " + (isEnabled ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int request, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(request, permissions, grantResults);
        // Logic for smsRequestCode
        if (request == smsRequestCode) {
            // Check if the permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSmsPreference(true);
            }
            else {
                // Permission denied so disable preference
                smsNotificationSwitch.setChecked(false);
                saveSmsPreference(false);
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_LONG).show();
            }
        }

        // Logic for lowInventoryCode
        if (request == lowInventoryCode) {
            // Check if the permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveLowInventoryPreference(true);
            }
            else {
                // Permission denied so disable preference
                lowInventoryNotificationSwitch.setChecked(false);
                saveLowInventoryPreference(false);
                Toast.makeText(this, "Low Inventory Notification permission denied.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // Method for allowing the back button to show up on the Update Inventory Activity page
    @Override
    public boolean onSupportNavigateUp() {
        // go back to Parent activity -> InventoryActivity
        finish();
        return true;
    }

}