package com.zybooks.projecttwo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;


import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {
    private Context context;
    private ArrayList category_name, category_ID;

    Activity activity;

    CategoryAdapter(Activity activity, Context context, ArrayList category_name, ArrayList category_ID){
        this.activity = activity;
        this.context = context;
        this.category_name = category_name;
        this.category_ID = category_ID;
    }

    @NonNull
    @Override
    public CategoryAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.category_row, parent, false);
        return new MyViewHolder(view);    }

    @Override
    public void onBindViewHolder(@NonNull CategoryAdapter.MyViewHolder holder, int position) {
        holder.category_name.setText(String.valueOf(category_name.get(position)));
        //holder.category_ID.setText(String.valueOf(category_ID.get(position)));

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, InventoryActivity.class);
            intent.putExtra("category_name", String.valueOf(category_name.get(position)));
            intent.putExtra("category_ID", Integer.parseInt(String.valueOf(category_ID.get(position))));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return category_name.size();
    }

    public class MyViewHolder extends ViewHolder {
        TextView category_name;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            category_name = itemView.findViewById(R.id.category_name);

        }
    }
}
